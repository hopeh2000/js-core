// See the console log, all tests must be passed in Internet Explorer 8, Mozilla Firefox 2+ and Safari 3+

window.onload = function() {

	var node = document.getElementById('test');

	console.log(node.firstElementChild.tagName === 'P');
	console.log(node.lastElementChild.tagName === 'ADDRESS');

	node = node.firstElementChild;
	console.log(node.nextElementSibling.tagName === 'ADDRESS');

	node = node.nextElementSibling;
	console.log(node.previousElementSibling.tagName === 'P');
	console.log(node.nextElementSibling === null);

	node = node.parentNode;
	console.log(node.childElementCount === 2);

	var p = document.createElement('p');

	console.log(p.firstElementChild === null);
	console.log(p.lastElementChild === null);
	console.log(p.nextElementSibling === null);
	console.log(p.previousElementSibling === null);
	console.log(p.childElementCount === 0);

};