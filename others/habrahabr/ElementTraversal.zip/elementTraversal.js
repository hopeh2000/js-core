/*
 * Implement ElementTraversal interface for Internet Explorer 8, Mozilla Firefox 2+ and Safari 3+
 * Specification: http://www.w3.org/TR/ElementTraversal/
 *
 * Author: Dmitry A Korobkin
 * Site: http://www.js-core.ru/
 */

(function() {

	var element = document.createElement("div");

	if(typeof element.firstElementChild == "undefined") {

		var ElementTravrsal = {
			firstElementChild: function() {
				var node = this.firstChild;
				while(node) {
					if(node.nodeType == 1) break;
					node = node.nextSibling;
				}
				return node;
			},
			lastElementChild: function() {
				var node = this.lastChild;
				while(node) {
					if(node.nodeType == 1) break;
					node = node.previousSibling;
				}
				return node;
			},
			nextElementSibling: function() {
				var node = this.nextSibling;
				while(node) {
					if(node.nodeType == 1) break;
					node = node.nextSibling;
				}
				return node;
			},
			previousElementSibling: function() {
				var node = this.previousSibling;
				while(node) {
					if(node.nodeType == 1) break;
					node = node.previousSibling;
				}
				return node;
			},
			childElementCount: typeof element.children == "undefined" ? function() {
				var list = this.childNodes, i = list.length, j = 0;
				while(i--) if(list[i].nodeType == 1) j++;
				return j;
			} : function() {
				return this.children.length;
			}
		};

		// IE8
		if(Object.defineProperty)
			for(var property in ElementTravrsal)
				if(ElementTravrsal.hasOwnProperty(property))
					Object.defineProperty(Element.prototype, property, {
						get: ElementTravrsal[property]
					});

		// Firefox 2+ and Safari 3+
		if(Object.__defineGetter__)
			for(var property in ElementTravrsal)
				if(ElementTravrsal.hasOwnProperty(property))
					HTMLElement.prototype.__defineGetter__(property, ElementTravrsal[property]);

	}

})();